AFAQ SYRIA - Payments Page

1. Upload payments.html to the root of your GitHub repository:
   oa626114-boop/afaq-syria
2. Open index.html and add a menu link:
   <a href="payments.html">المدفوعات والفواتير | Payments & Invoices</a>
3. Commit the changes and wait for GitHub Pages to publish.

Important: This is a front-end demo page. It does not process real payments until a payment provider API is securely connected.
