const CACHE = 'afaq-syria-v8';
const CORE = ['./','./index.html','./payment.html','./crypto-wallet.html','./global-market.html','./manifest.webmanifest','./icon.svg','./icon-192.png','./icon-512.png','./afaq-virtual-card-art.png','./afaq-crypto-card-art.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('afaq-syria-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  if (req.mode === 'navigate' || /\.html$/.test(new URL(req.url).pathname)) {
    event.respondWith(fetch(req).then(res => { if(res.ok){const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy));} return res; }).catch(() => caches.match(req).then(hit => hit || caches.match('./index.html'))));
    return;
  }
  event.respondWith(caches.match(req).then(hit => hit || fetch(req).then(res => { if(res.ok){const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy));} return res; })));
});
