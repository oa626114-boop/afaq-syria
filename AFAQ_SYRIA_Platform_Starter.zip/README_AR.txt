# AFAQ SYRIA Platform — starter package

## Files
- `dashboard.html`: responsive Arabic admin dashboard, sidebar navigation, invoice form, invoice/customer tables, reports export, integration status, API URL test.
- `worker.js`: Cloudflare Worker starter with health route, invoice persistence and IPN signature-verification scaffold.
- `schema.sql`: safe `CREATE TABLE IF NOT EXISTS` schema.
- `homepage-button.html`: button snippet to add to the existing AFAQ SYRIA public homepage.

## Important status
This is a working UI scaffold, not a live financial platform. Dashboard data is local demo data until the frontend is connected to authenticated backend endpoints. Invoice creation route persists invoices, but it deliberately does NOT fabricate a NOWPayments checkout URL. Card processing, bank transfer initiation, wallet custody and settlements are not activated.

## Deploy safely
1. Keep your existing public website `index.html` unchanged. Upload `dashboard.html` as a separate file first (for example `/dashboard.html`).
2. Add the homepage button snippet to your existing homepage where appropriate.
3. In Cloudflare D1, run `schema.sql` only after confirming table names; it uses `IF NOT EXISTS` and does not delete existing tables.
4. Create a separate staging Worker for this starter. Do not overwrite `omax-api-105a` until its full current source has been reviewed and merged safely.
5. Bind D1 database as `DB`.
6. Add Worker secrets by name only: `NOWPAYMENTS_API_KEY`, `NOWPAYMENTS_IPN_SECRET`. Never share secret values in chat or commit them to Git.
7. Set the exact production website origin in CORS. The sample currently permits `https://oa626114-boop.github.io`; adjust only to the actual origin hosting the dashboard.
8. Add Cloudflare Access / authentication before exposing admin endpoints. Do not expose customer data or wallet administration publicly.
9. Verify NOWPayments current API and IPN signing docs, payment currency/network support, amounts and order association. Test with a small permitted test payment before go-live.

## Existing project preservation
The current website is an investment showcase and should remain intact. The dashboard is separate. The existing Worker contains earlier NOWPayments functionality and must be reviewed before changing it; this starter is intentionally separate to avoid breaking that integration.

## Security
- Do not put API keys, IPN secrets, seed phrases, private keys, SSH passwords or recovery phrases in HTML, browser storage, D1 or GitHub.
- Do not mark invoices paid from browser actions. Only verified server-side provider callbacks may change payment state.
- Visa/Mastercard requires an approved acquiring provider, eligible legal entity and settlement bank account. Bank APIs require provider documentation and authorization.
- Alchemy is blockchain infrastructure, not a merchant checkout or settlement gateway.
