-- AFAQ SYRIA schema additions. Existing tables are not dropped or overwritten.
CREATE TABLE IF NOT EXISTS afaq_invoices (
 id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_number TEXT NOT NULL UNIQUE,
 payment_order_id TEXT, customer_name TEXT, customer_email TEXT, description TEXT,
 amount TEXT NOT NULL, currency TEXT NOT NULL, payment_method TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS afaq_wallets (
 id INTEGER PRIMARY KEY AUTOINCREMENT, wallet_name TEXT, asset TEXT, network TEXT,
 wallet_address TEXT, wallet_type TEXT DEFAULT 'company', is_active INTEGER DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS afaq_supported_assets (
 id INTEGER PRIMARY KEY AUTOINCREMENT, asset_code TEXT NOT NULL, asset_name TEXT,
 network_code TEXT NOT NULL, network_name TEXT, contract_address TEXT, decimals INTEGER,
 is_active INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(asset_code,network_code)
);
CREATE TABLE IF NOT EXISTS afaq_payment_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_number TEXT NOT NULL, provider TEXT NOT NULL,
 transaction_id TEXT, tx_hash TEXT, asset TEXT, network TEXT, amount TEXT,
 status TEXT DEFAULT 'pending', confirmations INTEGER DEFAULT 0, verified INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_afaq_events_invoice ON afaq_payment_events(invoice_number);
CREATE INDEX IF NOT EXISTS idx_afaq_events_hash ON afaq_payment_events(tx_hash);
CREATE TABLE IF NOT EXISTS afaq_integrations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, provider_name TEXT, integration_type TEXT,
 api_endpoint TEXT, status TEXT DEFAULT 'not_configured', environment TEXT DEFAULT 'test',
 last_checked_at TEXT, notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(provider_name,integration_type)
);
CREATE TABLE IF NOT EXISTS afaq_bank_accounts (
 id INTEGER PRIMARY KEY AUTOINCREMENT, bank_name TEXT, account_holder TEXT, country TEXT,
 currency TEXT, iban TEXT, account_reference TEXT,
 settlement_method TEXT DEFAULT 'bank_transfer', is_active INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
