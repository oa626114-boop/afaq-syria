/**
 * AFAQ SYRIA Worker starter — deploy as a SEPARATE staging Worker first.
 * Bind D1 as DB. Add secrets NOWPAYMENTS_API_KEY and NOWPAYMENTS_IPN_SECRET.
 * Never paste secrets into frontend code or commit them to Git.
 */
const cors = {
 "Access-Control-Allow-Origin": "https://oa626114-boop.github.io",
 "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
 "Access-Control-Allow-Headers": "Content-Type,Authorization",
 "Content-Type":"application/json; charset=utf-8"
};
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:cors});
const id=()=>crypto.randomUUID();
async function hmac(secret,message){
 const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-512"},false,["sign"]);
 const sig=await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(message));
 return [...new Uint8Array(sig)].map(b=>b.toString(16).padStart(2,"0")).join("");
}
function safeEqual(a,b){if(a.length!==b.length)return false;let n=0;for(let i=0;i<a.length;i++)n|=a.charCodeAt(i)^b.charCodeAt(i);return n===0}
async function body(req){try{return await req.json()}catch{return null}}
export default {
 async fetch(req,env){
  if(req.method==="OPTIONS")return new Response(null,{headers:cors});
  const url=new URL(req.url), path=url.pathname;
  try{
   if(path==="/health")return json({success:true,service:"AFAQ SYRIA Payments API",status:"worker_online",time:new Date().toISOString()});
   if(path==="/ipn"&&req.method==="POST"){
    const raw=await req.text(), data=JSON.parse(raw);
    const supplied=req.headers.get("x-nowpayments-sig")||"";
    if(!env.NOWPAYMENTS_IPN_SECRET)return json({error:"IPN secret missing"},503);
    // NOWPayments signs the sorted JSON payload; confirm current provider specification before go-live.
    const canonical=JSON.stringify(sortObject(data));
    const expected=await hmac(env.NOWPAYMENTS_IPN_SECRET,canonical);
    if(!safeEqual(expected.toLowerCase(),supplied.toLowerCase()))return json({error:"INVALID_SIGNATURE"},401);
    const order=String(data.order_id||"");
    if(!order)return json({error:"order_id missing"},400);
    await env.DB.prepare("UPDATE afaq_invoices SET status=?, updated_at=CURRENT_TIMESTAMP WHERE invoice_number=?")
      .bind(String(data.payment_status||"pending"),order).run();
    await env.DB.prepare("INSERT INTO afaq_payment_events(invoice_number,provider,transaction_id,tx_hash,asset,network,amount,status,verified) VALUES(?,?,?,?,?,?,?,?,1)")
      .bind(order,"NOWPayments",String(data.payment_id||""),String(data.payin_hash||""),String(data.pay_currency||""),String(data.network||""),String(data.actually_paid||data.price_amount||""),String(data.payment_status||"pending")).run();
    return json({success:true});
   }
   if(path==="/api/invoices"&&req.method==="POST"){
    const b=await body(req);if(!b)return json({error:"Invalid JSON"},400);
    const amount=Number(b.amount);
    if(!Number.isFinite(amount)||amount<=0||amount>10000000)return json({error:"Invalid amount"},400);
    const currency=String(b.currency||"USD").toUpperCase();
    if(!["USD","EUR","TRY"].includes(currency))return json({error:"Unsupported invoice currency"},400);
    const invoice="AFQ-"+crypto.randomUUID().slice(0,8).toUpperCase();
    await env.DB.prepare("INSERT INTO afaq_invoices(invoice_number,customer_name,customer_email,description,amount,currency,payment_method,status) VALUES(?,?,?,?,?,?,?,'pending')")
      .bind(invoice,String(b.customer_name||"Customer").slice(0,150),String(b.customer_email||"").slice(0,200),String(b.description||"").slice(0,500),String(amount),currency,String(b.payment_method||"crypto")).run();
    // Provider checkout is intentionally not fabricated. Configure and test provider-specific payment creation here.
    return json({success:true,invoice_number:invoice,status:"pending",checkout_url:null,message:"Invoice saved. Payment provider checkout is not enabled in this starter."},201);
   }
   // Admin routes must be protected by Cloudflare Access or a proper auth layer before enabling.
   return json({error:"Not found"},404);
  }catch(e){return json({error:"Internal server error",detail:env.ENVIRONMENT==="development"?String(e):undefined},500)}
 }
};
function sortObject(value){
 if(Array.isArray(value))return value.map(sortObject);
 if(value&&typeof value==="object")return Object.keys(value).sort().reduce((o,k)=>(o[k]=sortObject(value[k]),o),{});
 return value;
}
